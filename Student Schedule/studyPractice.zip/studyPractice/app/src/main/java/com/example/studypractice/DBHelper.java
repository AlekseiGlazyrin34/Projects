package com.example.studypractice;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
// конструктор суперкласса
        super(context, "myDBAlex", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Schedule(" + "id integer primary key autoincrement ," + "date text," + "para1 text," + "para2 text," +"para3 text" +");");
        db.execSQL("create table Users(" + "id integer primary key autoincrement ," + "username text," + "password text," + "name text"+ ");");
        insertData(db);
    }

    public void insertData(SQLiteDatabase db){

        ContentValues cv =new ContentValues();

        cv.put("username","Alexey");
        cv.put("password", "lesha2005");
        cv.put("name", "Алексей");
        db.insert("Users", null, cv);
        cv.clear();

        cv.put("username","Ivan");
        cv.put("password", "ivan2000");
        cv.put("name", "Иван");
        db.insert("Users", null, cv);
        cv.clear();

        cv.put("username","Dmitry");
        cv.put("password", "dima2012");
        cv.put("name", "Алексей");
        db.insert("Users", null, cv);
        cv.clear();

        cv.put("username","Masha");
        cv.put("password", "mari34");
        cv.put("name", "Мария");
        db.insert("Users", null, cv);
        cv.clear();

        cv.put("date","20.05.2024");
        cv.put("para1", "информатика ауд. 345");
        cv.put("para2", "литература фуд. 360");
        db.insert("Schedule", null, cv);
        cv.clear();

        cv.put("date","21.05.2024");
        cv.put("para1", "математика ауд. 429");
        cv.put("para2", "математика ауд. 429");
        db.insert("Schedule", null, cv);
        cv.clear();

        cv.put("date","22.05.2024");
        cv.put("para2", "география ауд. 248");
        cv.put("para3", "история ауд. 268");
        db.insert("Schedule", null, cv);
        cv.clear();

        cv.put("date","23.05.2024");
        cv.put("para1", "математика ауд. 429");
        cv.put("para2", "русский язык ауд. 360");
        db.insert("Schedule", null, cv);
        cv.clear();

        cv.put("date","24.05.2024");
        cv.put("para1", "математика ауд. 429");
        cv.put("para2", "литература фуд. 360");
        cv.put("para3", "информатика ауд. 345");
        db.insert("Schedule", null, cv);
        cv.clear();

        cv.put("date","25.05.2024");
        cv.put("para1", "математика ауд. 429");
        cv.put("para2", "общество ауд. 268");
        db.insert("Schedule", null, cv);
        cv.clear();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

