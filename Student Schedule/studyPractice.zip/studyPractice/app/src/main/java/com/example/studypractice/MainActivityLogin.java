package com.example.studypractice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Objects;


public class MainActivityLogin extends AppCompatActivity  {
    Button btnLogin;
    EditText EDLog,EDPass;
    TextView Error;
    DBHelper dbHelper;
    String login,pass;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        btnLogin = (Button) findViewById(R.id.btnLog);
        EDLog= (EditText) findViewById(R.id.login);
        EDPass= (EditText) findViewById(R.id.password);
        dbHelper = new DBHelper(this);
        Error = (TextView) findViewById(R.id.error);

    }

    public void Login(View view){
        Intent intent = new Intent(this, Loading.class);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        login = EDLog.getText().toString();
        pass = EDPass.getText().toString();
        int check =0;
        Cursor c = db.query("Users", null, null, null, null, null, null);
        if (c.moveToFirst()) {
            int usernameColIndex = c.getColumnIndex("username");
            int passwordColIndex = c.getColumnIndex("password");
            int nameColIndex = c.getColumnIndex("name");

            do {
                if(Objects.equals(login, c.getString(usernameColIndex)) && Objects.equals(pass, c.getString(passwordColIndex))){
                    Toast toast = Toast.makeText(getApplicationContext(), "норм", Toast.LENGTH_LONG);
                    toast.show();
                    check=1;
                    Error.setVisibility(View.INVISIBLE);
                    intent.putExtra("name",c.getString(nameColIndex));
                    startActivity(intent);

                }
            } while (c.moveToNext());
            if (check==0) Error.setVisibility(View.VISIBLE);
        }
        c.close();


    }
    }